This folder is for product images. Placeholder colored boxes are used in the project instead of real images, so this folder is currently empty.
